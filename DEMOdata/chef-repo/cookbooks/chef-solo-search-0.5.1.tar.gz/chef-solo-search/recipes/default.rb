# This file is intentionally blank, which allows this
# entire repository to be used as a cookbook
